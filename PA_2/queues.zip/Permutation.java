import edu.princeton.cs.algs4.StdIn;

public class Permutation {
    public static void main(String[] args) {

        int printQuantity = Integer.parseInt(args[0]);

        RandomizedQueue<String> random = new RandomizedQueue<>();

        while (!StdIn.isEmpty()) {

            String current = StdIn.readString();

            random.enqueue(current);

        }

        for (int i = 0; i < printQuantity; i++) {
            System.out.println(random.dequeue());
        }

    }
}
